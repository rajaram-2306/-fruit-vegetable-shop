import { Product, ServiceItem } from '../types';

export const PRODUCTS: Product[] = [
  // FRUITS CATEGORY
  {
    id: 'fruit-apple',
    name: 'Apple (Kashmiri Red)',
    category: 'fruit',
    price: 180,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=600&q=80',
    description: 'Crisp, juicy and sweet Kashmiri apples sourced directly from prime orchards. Rich in fiber & antioxidants.',
    isPopular: true,
    stockStatus: 'In Stock',
    origin: 'Shimla & Kashmir',
    benefits: ['Boosts immunity', 'Promotes heart health', 'Rich in dietary fiber']
  },
  {
    id: 'fruit-banana',
    name: 'Yellow Banana (Robusta / Sevazhai)',
    category: 'fruit',
    price: 50,
    unit: '1 dozen (12 pcs)',
    image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=600&q=80',
    description: 'Naturally ripened nutrient-rich sweet bananas from local farms around Dindigul. Excellent instant energy booster.',
    isPopular: true,
    stockStatus: 'In Stock',
    origin: 'Theni & Dindigul Farms',
    benefits: ['Instant energy', 'High potassium', 'Supports digestion']
  },
  {
    id: 'fruit-mango',
    name: 'Alphonso / Banganapalli Mango',
    category: 'fruit',
    price: 140,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=600&q=80',
    description: 'King of fruits! Premium quality naturally ripened sweet mangoes with heavenly aroma and smooth pulp.',
    isPopular: true,
    isFreshArrival: true,
    stockStatus: 'In Stock',
    origin: 'Salem & Dindigul Orchards',
    benefits: ['Rich in Vitamin A & C', 'Enhances immunity', 'Delicious summer treat']
  },
  {
    id: 'fruit-orange',
    name: 'Juicy Sweet Orange (Nagpur)',
    category: 'fruit',
    price: 90,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1547514701-42782101795e?auto=format&fit=crop&w=600&q=80',
    description: 'Citrusy, sweet and bursting with Vitamin C juice. Handpicked for fresh breakfast juice and healthy snacking.',
    isPopular: false,
    stockStatus: 'In Stock',
    origin: 'Nagpur Farms',
    benefits: ['High Vitamin C', 'Hydrating', 'Promotes glowing skin']
  },
  {
    id: 'fruit-watermelon',
    name: 'Farm-Fresh Sweet Watermelon',
    category: 'fruit',
    price: 45,
    unit: '1 piece (~3-4 kg)',
    image: 'https://images.unsplash.com/photo-1589984662646-e7b2e4962f18?auto=format&fit=crop&w=600&q=80',
    description: 'Deep red, crisp, extra juicy watermelons. Perfect cooling refresher for warm Tamil Nadu days.',
    isPopular: true,
    stockStatus: 'In Stock',
    origin: 'Local Dindigul Fields',
    benefits: ['92% water content', 'Lycopene rich', 'Electrolyte balancing']
  },
  {
    id: 'fruit-pineapple',
    name: 'Queen Pineapple',
    category: 'fruit',
    price: 65,
    unit: '1 piece',
    image: 'https://images.unsplash.com/photo-1550258987-190a2d41a8ba?auto=format&fit=crop&w=600&q=80',
    description: 'Tangy-sweet aromatic pineapple packed with digestive enzymes and anti-inflammatory properties.',
    isPopular: false,
    stockStatus: 'In Stock',
    origin: 'Kerala & Kanyakumari',
    benefits: ['Contains Bromelain', 'Supports digestion', 'Immunity booster']
  },
  {
    id: 'fruit-grapes',
    name: 'Seedless Black & Green Grapes',
    category: 'fruit',
    price: 110,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1537640538966-79f369143f8f?auto=format&fit=crop&w=600&q=80',
    description: 'Crisp, sweet, seedless grapes carefully selected for maximum sweetness and freshness.',
    isPopular: true,
    stockStatus: 'In Stock',
    origin: 'Cinnamanoor & Nashik',
    benefits: ['Heart-healthy antioxidants', 'Low calories', 'Boosts brain focus']
  },
  {
    id: 'fruit-guava',
    name: 'Country Pink & White Guava',
    category: 'fruit',
    price: 80,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1536511135882-70b741005fbd?auto=format&fit=crop&w=600&q=80',
    description: 'Fresh crunchy local guavas with heavenly aroma. Extremely rich in Vitamin C and fiber.',
    isPopular: false,
    isOrganic: true,
    stockStatus: 'In Stock',
    origin: 'Dindigul Village Farms',
    benefits: ['4x Vitamin C of oranges', 'Regulates blood sugar', 'Improves digestion']
  },

  // VEGETABLES CATEGORY
  {
    id: 'veg-tomato',
    name: 'Farm Fresh Country Tomato',
    category: 'vegetable',
    price: 35,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80',
    description: 'Firm, bright red tangy country tomatoes harvested daily from Balakrishnapuram local gardens.',
    isPopular: true,
    stockStatus: 'In Stock',
    origin: 'Balakrishnapuram local',
    benefits: ['Rich in Lycopene', 'Essential for South Indian sambar & rasam']
  },
  {
    id: 'veg-potato',
    name: 'Nilgiri / Ooty Fresh Potato',
    category: 'vegetable',
    price: 30,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=600&q=80',
    description: 'Clean, smooth, starch-rich potatoes ideal for curry, fries, and daily cooking.',
    isPopular: true,
    stockStatus: 'In Stock',
    origin: 'Ooty & Kodaikanal Hills',
    benefits: ['High carbohydrate energy', 'Potassium source', 'Versatile daily staple']
  },
  {
    id: 'veg-onion',
    name: 'Small Shallots (Chinna Vengayam) & Big Red Onion',
    category: 'vegetable',
    price: 45,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cf?auto=format&fit=crop&w=600&q=80',
    description: 'Pungent, flavorful small shallots and big onions essential for authentic Tamil Nadu cuisine.',
    isPopular: true,
    stockStatus: 'In Stock',
    origin: 'Dindigul & Perambalur',
    benefits: ['Natural antibiotic properties', 'Enhances immunity & flavor']
  },
  {
    id: 'veg-carrot',
    name: 'Ooty Crunchy Red Carrot',
    category: 'vegetable',
    price: 60,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1598170845058-12ef4a45753b?auto=format&fit=crop&w=600&q=80',
    description: 'Sweet, crisp carrots straight from Ooty hill station gardens. High beta-carotene content.',
    isPopular: true,
    isOrganic: true,
    stockStatus: 'In Stock',
    origin: 'Ooty Hill Farms',
    benefits: ['Promotes eye health', 'Great for salads and juices']
  },
  {
    id: 'veg-brinjal',
    name: 'Fresh Purple & Green Brinjal (Kathirikai)',
    category: 'vegetable',
    price: 40,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80',
    description: 'Tender, seedless local brinjals perfect for Ennai Kathirikai gravy and Kara Kuzhambu.',
    isPopular: false,
    stockStatus: 'In Stock',
    origin: 'Balakrishnapuram Fields',
    benefits: ['Low calorie', 'Rich in dietary antioxidants']
  },
  {
    id: 'veg-cabbage',
    name: 'Fresh Green Cabbage (Muttakose)',
    category: 'vegetable',
    price: 35,
    unit: '1 head (~1 kg)',
    image: 'https://images.unsplash.com/photo-1594282486552-05b4d80fbb9f?auto=format&fit=crop&w=600&q=80',
    description: 'Tight, crisp green cabbage heads packed with essential vitamins and fiber.',
    isPopular: false,
    stockStatus: 'In Stock',
    origin: 'Hosur & Kodaikanal',
    benefits: ['Excellent for digestive health', 'Rich in Vitamin K']
  },
  {
    id: 'veg-ladiesfinger',
    name: 'Tender Ladies Finger (Vendaikai)',
    category: 'vegetable',
    price: 45,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1425543103986-22abb7d7e8d2?auto=format&fit=crop&w=600&q=80',
    description: 'Extra tender, break-fresh okra (vendaikai) handpicked every morning for crispy stir fry.',
    isPopular: true,
    stockStatus: 'In Stock',
    origin: 'Dindigul Local Farms',
    benefits: ['High folate & mucilage', 'Good for joint health & memory']
  },
  {
    id: 'veg-drumstick',
    name: 'Organic Country Drumstick (Murungakkai)',
    category: 'vegetable',
    price: 50,
    unit: '1 bundle (~500g)',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
    description: 'Aromatic, fleshy country drumsticks harvested fresh. Unmatched flavor for authentic Sambar.',
    isPopular: true,
    isOrganic: true,
    stockStatus: 'In Stock',
    origin: 'Moolanur & Dindigul',
    benefits: ['Superfood nutrient profile', 'Strengthens bones & blood purification']
  },
  {
    id: 'veg-beetroot',
    name: 'Ooty Deep Red Beetroot',
    category: 'vegetable',
    price: 50,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1528825871115-3581a5387919?auto=format&fit=crop&w=600&q=80',
    description: 'Earthy, sweet red beetroots full of natural nitrites and iron for healthy blood circulation.',
    isPopular: false,
    stockStatus: 'In Stock',
    origin: 'Kodaikanal Hills',
    benefits: ['Improves stamina', 'Natural iron supplement']
  },
  {
    id: 'veg-beans',
    name: 'French Beans & Cluster Beans (Avarakkai / Beans)',
    category: 'vegetable',
    price: 70,
    unit: '1 kg',
    image: 'https://images.unsplash.com/photo-1567375698348-5d9d5ae99de0?auto=format&fit=crop&w=600&q=80',
    description: 'Crisp, tender green beans free from stringiness. Ideal for South Indian poriyal and pulav.',
    isPopular: true,
    stockStatus: 'In Stock',
    origin: 'Ooty Farms',
    benefits: ['High protein & fiber', 'Low glycemic index']
  },

  // ORGANIC & GROCERY EXTRAS
  {
    id: 'organic-greens',
    name: 'Assorted Organic Spinach & Keerai (Palak / Arai Keerai)',
    category: 'organic',
    price: 25,
    unit: '1 large bundle',
    image: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=600&q=80',
    description: 'Zero chemical pesticide green leafy keerais picked fresh at 6 AM every day.',
    isPopular: true,
    isOrganic: true,
    isFreshArrival: true,
    stockStatus: 'In Stock',
    origin: 'Balakrishnapuram Organic Farm',
    benefits: ['Iron powerhouse', 'Detoxifying greens']
  },
  {
    id: 'grocery-coconut',
    name: 'Fresh Pollachi Tender & Dry Coconut',
    category: 'grocery',
    price: 35,
    unit: '1 piece',
    image: 'https://images.unsplash.com/photo-1543362906-acfc16c67564?auto=format&fit=crop&w=600&q=80',
    description: 'Heavy, sweet water filled coconuts from Pollachi farms for cooking and cooling water.',
    isPopular: true,
    stockStatus: 'In Stock',
    origin: 'Pollachi Groves',
    benefits: ['Natural electrolyte replacement', 'Essential cooking staple']
  }
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'service-fresh-fruits',
    title: 'Fresh Fruits Supply',
    description: 'Daily morning procurement of handpicked premium domestic and imported fruits with 100% natural freshness guarantee.',
    iconName: 'Apple',
    image: 'https://images.unsplash.com/photo-1619566636858-adf3ef46400b?auto=format&fit=crop&w=600&q=80',
    badge: 'Popular'
  },
  {
    id: 'service-fresh-vegetables',
    title: 'Farm Fresh Vegetables',
    description: 'Direct procurement from local farmers around Dindigul, Ooty, and Kodaikanal ensuring zero cold storage delays.',
    iconName: 'Carrot',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
    badge: 'Daily Harvest'
  },
  {
    id: 'service-organic-veg',
    title: 'Certified Organic Vegetables',
    description: 'Pesticide-free, naturally grown greens, root vegetables, and fruits for health-conscious families.',
    iconName: 'Leaf',
    image: 'https://images.unsplash.com/photo-1595855759920-86582396756a?auto=format&fit=crop&w=600&q=80',
    badge: '100% Chemical Free'
  },
  {
    id: 'service-grocery',
    title: 'Essential Grocery Items',
    description: 'Daily kitchen essentials including coconut, tamarind, garlic, ginger, and traditional pulses.',
    iconName: 'ShoppingBag',
    image: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'service-home-delivery',
    title: 'Express Home Delivery',
    description: 'Prompt doorstep delivery across Balakrishnapuram and Dindigul town. Free delivery on orders above ₹300.',
    iconName: 'Truck',
    image: 'https://images.unsplash.com/photo-1580674684081-7617fbf3d745?auto=format&fit=crop&w=600&q=80',
    badge: 'Same Day'
  },
  {
    id: 'service-bulk-orders',
    title: 'Bulk & Wholesale Supplies',
    description: 'Competitive wholesale rates for restaurants, hotels, hostels, marriage functions, and canteens.',
    iconName: 'Boxes',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
    badge: 'Best Rates'
  },
  {
    id: 'service-festival-orders',
    title: 'Festival & Special Event Packages',
    description: 'Custom fruit hampers and vegetable basket prep for Pongal, Diwali, temple pujas, and weddings.',
    iconName: 'Gift',
    image: 'https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=600&q=80'
  }
];
