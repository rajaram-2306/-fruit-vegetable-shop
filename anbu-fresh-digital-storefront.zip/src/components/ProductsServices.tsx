import React, { useState } from 'react';
import { Product, ProductCategory } from '../types';
import { PRODUCTS, SERVICES } from '../data/products';
import { ShoppingBag, Search, Filter, Sparkles, CheckCircle2, Truck, ArrowRight, MapPin, Tag, Phone, ShieldCheck } from 'lucide-react';

interface ProductsServicesProps {
  onAddToCart: (product: Product) => void;
  onBuyNow: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export const ProductsServices: React.FC<ProductsServicesProps> = ({
  onAddToCart,
  onBuyNow,
  onSelectProduct,
}) => {
  const [activeTab, setActiveTab] = useState<'products' | 'services'>('products');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'default' | 'price-low' | 'price-high' | 'name'>('default');

  // Filter Products
  let filteredProducts = PRODUCTS.filter((product) => {
    const matchesCategory =
      selectedCategory === 'all' ||
      product.category === selectedCategory ||
      (selectedCategory === 'organic' && product.isOrganic);

    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (product.origin && product.origin.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCategory && matchesSearch;
  });

  // Sort Products
  if (sortBy === 'price-low') {
    filteredProducts.sort((a, b) => a.price - b.price);
  } else if (sortBy === 'price-high') {
    filteredProducts.sort((a, b) => b.price - a.price);
  } else if (sortBy === 'name') {
    filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Page Header */}
      <div className="bg-[#2D5A27] text-white rounded-3xl p-8 sm:p-12 shadow-xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-3 max-w-2xl">
          <span className="px-3 py-1 bg-[#F27D26] text-white font-extrabold text-xs uppercase tracking-wider rounded-full">
            Dindigul Daily Catalog
          </span>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
            Fresh Products & Wholesale Services
          </h1>
          <p className="text-gray-100 text-sm sm:text-base leading-relaxed">
            Browse handpicked seasonal fruits, farm-fresh vegetables, organic keerais, and custom bulk catering services available at Balakrishnapuram, Dindigul.
          </p>
        </div>

        {/* Top Segmented Control */}
        <div className="flex bg-white/10 backdrop-blur-md p-1.5 rounded-2xl border border-white/20 shrink-0">
          <button
            onClick={() => setActiveTab('products')}
            id="tab-products-btn"
            className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-all ${
              activeTab === 'products'
                ? 'bg-white text-[#2D5A27] shadow-md'
                : 'text-white hover:bg-white/10'
            }`}
          >
            Fresh Products ({PRODUCTS.length})
          </button>
          <button
            onClick={() => setActiveTab('services')}
            id="tab-services-btn"
            className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-all ${
              activeTab === 'services'
                ? 'bg-white text-[#2D5A27] shadow-md'
                : 'text-white hover:bg-white/10'
            }`}
          >
            Our Services ({SERVICES.length})
          </button>
        </div>
      </div>

      {activeTab === 'products' ? (
        <div className="space-y-8">
          {/* Controls Bar: Search + Category Pills + Sorting */}
          <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-sm border border-gray-200 space-y-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              {/* Search Bar */}
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  placeholder="Search apple, tomato, organic..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  id="product-search-input"
                  className="w-full pl-10 pr-4 py-2 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#4CAF50]"
                />
              </div>

              {/* Sort Dropdown */}
              <div className="flex items-center gap-2 w-full md:w-auto">
                <span className="text-xs font-bold text-gray-500 whitespace-nowrap">Sort By:</span>
                <select
                  value={sortBy}
                  onChange={(e: any) => setSortBy(e.target.value)}
                  id="product-sort-select"
                  className="px-3 py-2 rounded-xl border border-gray-300 text-xs font-semibold bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-[#4CAF50] w-full md:w-auto"
                >
                  <option value="default">Default Sourcing</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="name">Name: A to Z</option>
                </select>
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-gray-100">
              {(
                [
                  { id: 'all', label: 'All Items' },
                  { id: 'fruit', label: 'Fruits' },
                  { id: 'vegetable', label: 'Vegetables' },
                  { id: 'organic', label: '100% Organic' },
                  { id: 'grocery', label: 'Daily Grocery' },
                ] as const
              ).map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  id={`cat-filter-${cat.id}`}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                    selectedCategory === cat.id
                      ? 'bg-[#2D5A27] text-white shadow-xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Product Grid */}
          {filteredProducts.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-gray-200 p-8 space-y-3">
              <div className="text-4xl">🔍</div>
              <h3 className="text-xl font-bold text-gray-800">No items match your search</h3>
              <p className="text-xs text-gray-500">Try adjusting your category filter or search keywords.</p>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSearchQuery('');
                }}
                className="px-4 py-2 bg-[#2D5A27] text-white text-xs font-bold rounded-xl"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
                >
                  {/* Image Container */}
                  <div
                    className="relative cursor-pointer overflow-hidden bg-gray-50 h-52"
                    onClick={() => onSelectProduct(product)}
                  >
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />

                    <div className="absolute top-3 left-3 flex flex-col gap-1">
                      {product.isOrganic && (
                        <span className="px-2.5 py-0.5 bg-[#2D5A27] text-white text-[10px] font-extrabold rounded-full shadow-xs">
                          Organic
                        </span>
                      )}
                      {product.isPopular && (
                        <span className="px-2.5 py-0.5 bg-[#F27D26] text-white text-[10px] font-extrabold rounded-full shadow-xs">
                          ★ Bestseller
                        </span>
                      )}
                    </div>

                    <div className="absolute bottom-2 right-2 px-2 py-0.5 bg-black/60 text-white text-[10px] font-medium rounded-md backdrop-blur-xs">
                      {product.stockStatus}
                    </div>
                  </div>

                  {/* Body Details */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div>
                      <div className="flex items-center justify-between text-[11px] font-bold text-[#4CAF50] uppercase tracking-wider mb-1">
                        <span>{product.category}</span>
                        {product.origin && <span className="text-gray-400 font-normal">📍 {product.origin}</span>}
                      </div>

                      <h3
                        onClick={() => onSelectProduct(product)}
                        className="font-extrabold text-base text-gray-900 group-hover:text-[#2D5A27] cursor-pointer transition-colors line-clamp-1"
                      >
                        {product.name}
                      </h3>

                      <p className="text-gray-500 text-xs line-clamp-2 mt-1 leading-relaxed">
                        {product.description}
                      </p>
                    </div>

                    {/* Price & Action Buttons */}
                    <div className="pt-3 border-t border-gray-100 space-y-3">
                      <div className="flex items-baseline justify-between">
                        <span className="text-xs text-gray-500 font-semibold">Sample Price:</span>
                        <div>
                          <span className="text-xl font-black text-[#F27D26]">₹{product.price}</span>
                          <span className="text-xs text-gray-500 font-medium"> / {product.unit}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => onAddToCart(product)}
                          id={`product-card-cart-${product.id}`}
                          className="py-2.5 px-3 rounded-xl font-bold text-xs bg-[#F0FDF4] text-[#2D5A27] border border-[#4CAF50]/30 hover:bg-[#E1F9E6] transition-colors flex items-center justify-center gap-1.5"
                        >
                          <ShoppingBag className="w-3.5 h-3.5 text-[#2D5A27]" />
                          Add to Cart
                        </button>
                        <button
                          onClick={() => onBuyNow(product)}
                          id={`product-card-buynow-${product.id}`}
                          className="py-2.5 px-3 rounded-xl font-bold text-xs bg-[#F27D26] hover:bg-[#e06b17] text-white shadow-xs transition-transform active:scale-95 text-center"
                        >
                          Buy Now
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* SERVICES SECTION */
        <div className="space-y-8">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <span className="text-xs font-bold text-[#F27D26] uppercase tracking-wider">Comprehensive Produce Sourcing</span>
            <h2 className="text-3xl font-extrabold text-[#2D5A27]">Our Specialized Services</h2>
            <p className="text-gray-600 text-sm">Providing retail and commercial produce solutions across Dindigul district.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES.map((srv) => (
              <div
                key={srv.id}
                className="bg-white rounded-3xl border border-gray-200 overflow-hidden shadow-xs hover:shadow-lg transition-all space-y-4 p-6 flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="relative h-44 rounded-2xl overflow-hidden bg-gray-100">
                    <img
                      src={srv.image}
                      alt={srv.title}
                      className="w-full h-full object-cover"
                    />
                    {srv.badge && (
                      <span className="absolute top-3 left-3 px-3 py-1 bg-[#2D5A27] text-white font-extrabold text-xs rounded-full shadow-sm">
                        {srv.badge}
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="text-xl font-extrabold text-[#2D5A27] mb-1">{srv.title}</h3>
                    <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">{srv.description}</p>
                  </div>
                </div>

                <a
                  href={`https://wa.me/919487602371?text=Hello%20Anbu%20Shop,%20I%20am%20interested%20in%20your%20${encodeURIComponent(
                    srv.title
                  )}%20service.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 rounded-xl font-bold text-xs bg-[#F27D26] hover:bg-[#e06b17] text-white flex items-center justify-center gap-2 transition-colors shadow-xs"
                >
                  Inquire For Service
                </a>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
