import React, { useState } from 'react';
import { GalleryItem } from '../types';
import { X, ZoomIn, Sparkles, Filter } from 'lucide-react';

export const Gallery: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeImage, setActiveImage] = useState<GalleryItem | null>(null);

  const galleryItems: GalleryItem[] = [
    {
      id: 'g-1',
      title: 'Storefront Display',
      category: 'store',
      image: 'https://images.unsplash.com/photo-1610348725531-843dff563e2c?auto=format&fit=crop&w=1000&q=80',
      caption: 'Neatly arranged fresh fruits and wooden produce crates at Balakrishnapuram store entrance.',
    },
    {
      id: 'g-2',
      title: 'Organic Keerai & Vegetables',
      category: 'vegetables',
      image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=1000&q=80',
      caption: 'Chemical-free fresh green spinach, drumsticks, and country tomatoes picked at dawn.',
    },
    {
      id: 'g-3',
      title: 'Kashmiri Red Apples',
      category: 'fruits',
      image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=1000&q=80',
      caption: 'Crisp, juicy premium Kashmiri red apples stacked for customer selection.',
    },
    {
      id: 'g-4',
      title: 'Tropical Mango Selection',
      category: 'fruits',
      image: 'https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=1000&q=80',
      caption: 'Naturally ripened Alphonso and Banganapalli mangoes with golden sweet aroma.',
    },
    {
      id: 'g-5',
      title: 'Ooty Fresh Carrots',
      category: 'vegetables',
      image: 'https://images.unsplash.com/photo-1598170845058-12ef4a45753b?auto=format&fit=crop&w=1000&q=80',
      caption: 'Crisp red Ooty hill station carrots rich in natural beta-carotene.',
    },
    {
      id: 'g-6',
      title: 'Pollachi Coconuts & Staples',
      category: 'grocery',
      image: 'https://images.unsplash.com/photo-1543362906-acfc16c67564?auto=format&fit=crop&w=1000&q=80',
      caption: 'Heavy water-filled Pollachi coconuts essential for South Indian home cooking.',
    },
    {
      id: 'g-7',
      title: 'Juicy Watermelon Cut',
      category: 'arrivals',
      image: 'https://images.unsplash.com/photo-1589984662646-e7b2e4962f18?auto=format&fit=crop&w=1000&q=80',
      caption: 'Sweet deep red watermelon harvested fresh from local Dindigul fields.',
    },
    {
      id: 'g-8',
      title: 'Seedless Black Grapes',
      category: 'fruits',
      image: 'https://images.unsplash.com/photo-1537640538966-79f369143f8f?auto=format&fit=crop&w=1000&q=80',
      caption: 'Plump, seedless black grapes ready for family fruit bowls.',
    },
  ];

  const filteredItems = galleryItems.filter(
    (item) => selectedCategory === 'all' || item.category === selectedCategory
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Header */}
      <div className="bg-[#2D5A27] text-white rounded-3xl p-8 sm:p-12 shadow-xl relative overflow-hidden">
        <div className="space-y-3 max-w-2xl">
          <span className="px-3 py-1 bg-[#F27D26] text-white font-extrabold text-xs uppercase tracking-wider rounded-full">
            Visual Showcase
          </span>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
            Anbu Store Photo Gallery
          </h1>
          <p className="text-gray-100 text-sm sm:text-base leading-relaxed">
            Take a visual tour of our store in Balakrishnapuram, Dindigul, daily farm shipments, and organic produce selections.
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2 bg-white p-2 rounded-2xl border border-gray-200 shadow-xs">
        {(
          [
            { id: 'all', label: 'All Photos' },
            { id: 'fruits', label: 'Fresh Fruits' },
            { id: 'vegetables', label: 'Vegetables & Greens' },
            { id: 'store', label: 'Store Interior' },
            { id: 'grocery', label: 'Grocery Items' },
            { id: 'arrivals', label: 'Fresh Arrivals' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedCategory(tab.id)}
            id={`gallery-filter-${tab.id}`}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-colors ${
              selectedCategory === tab.id
                ? 'bg-[#2D5A27] text-white shadow-xs'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            onClick={() => setActiveImage(item)}
            className="group relative h-64 rounded-2xl overflow-hidden cursor-pointer shadow-xs hover:shadow-xl transition-all duration-300 border border-gray-200 bg-gray-100"
          >
            <img
              src={item.image}
              alt={item.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

            {/* Hover icon */}
            <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/20 backdrop-blur-md text-white flex items-center justify-center group-hover:scale-110 transition-transform">
              <ZoomIn className="w-4 h-4" />
            </div>

            {/* Caption Overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-4 text-white space-y-1">
              <div className="text-[10px] font-extrabold text-[#4CAF50] uppercase tracking-wider">
                {item.category}
              </div>
              <h3 className="font-extrabold text-base leading-tight">{item.title}</h3>
              <p className="text-xs text-gray-200 line-clamp-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                {item.caption}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      {activeImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
          onClick={() => setActiveImage(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setActiveImage(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/50 text-white hover:bg-black transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <img
              src={activeImage.image}
              alt={activeImage.title}
              className="w-full h-96 sm:h-[450px] object-cover"
            />

            <div className="p-6 bg-white space-y-2">
              <span className="text-xs font-bold text-[#4CAF50] uppercase tracking-wider">
                {activeImage.category} • Anbu Shop Dindigul
              </span>
              <h3 className="text-2xl font-extrabold text-gray-900">{activeImage.title}</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{activeImage.caption}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
