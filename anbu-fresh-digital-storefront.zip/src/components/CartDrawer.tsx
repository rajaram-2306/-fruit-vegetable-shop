import React, { useState } from 'react';
import { CartItem } from '../types';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, MessageCircle, CheckCircle, Truck, AlertCircle } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [address, setAddress] = useState('Balakrishnapuram, Dindigul');
  const [orderPlaced, setOrderPlaced] = useState(false);

  if (!isOpen) return null;

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );
  const deliveryFee = subtotal >= 300 || subtotal === 0 ? 0 : 30;
  const total = subtotal + deliveryFee;

  const handleCheckoutWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItems.length === 0) return;

    let itemsList = cartItems
      .map(
        (item, idx) =>
          `${idx + 1}. ${item.product.name} x ${item.quantity} (${item.product.unit}) = ₹${
            item.product.price * item.quantity
          }`
      )
      .join('%0A');

    const message = `*NEW ORDER - ANBU FRUIT %26 VEGETABLE SHOP*%0A%0A*Customer Name:* ${encodeURIComponent(
      customerName || 'Valued Customer'
    )}%0A*Mobile:* ${encodeURIComponent(
      mobileNumber || 'Not provided'
    )}%0A*Delivery Address:* ${encodeURIComponent(
      address
    )}%0A%0A*ITEMS ORDERED:*%0A${itemsList}%0A%0A*Subtotal:* ₹${subtotal}%0A*Delivery Fee:* ₹${deliveryFee}%0A*TOTAL AMOUNT:* ₹${total}%0A%0APlease confirm availability and delivery slot. Thank you!`;

    window.open(`https://wa.me/919487602371?text=${message}`, '_blank');
    setOrderPlaced(true);
    setTimeout(() => {
      onClearCart();
      setOrderPlaced(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between relative animate-slideLeft">
        {/* Cart Header */}
        <div className="p-5 bg-[#2D5A27] text-white flex items-center justify-between border-b border-[#4CAF50]/30">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-6 h-6 text-[#F27D26]" />
            <div>
              <h2 className="font-extrabold text-lg leading-tight">Your Cart Basket</h2>
              <span className="text-xs text-[#4CAF50] font-medium">
                {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'} selected
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            id="cart-drawer-close"
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Alert overlay */}
        {orderPlaced ? (
          <div className="flex-1 p-8 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#F0FDF4] text-[#4CAF50] flex items-center justify-center animate-bounce">
              <CheckCircle className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-black text-[#2D5A27]">Order Dispatched!</h3>
            <p className="text-sm text-gray-600">
              Opening WhatsApp with your formatted produce list for Anbu Fruit & Vegetable Shop.
            </p>
          </div>
        ) : cartItems.length === 0 ? (
          /* Empty State */
          <div className="flex-1 p-8 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center text-gray-400">
              <ShoppingBag className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-gray-800">Your basket is empty</h3>
            <p className="text-sm text-gray-500 max-w-xs">
              Explore our fresh fruits, farm vegetables, and organic keerais to fill your basket!
            </p>
            <button
              onClick={onClose}
              id="empty-cart-continue-btn"
              className="px-6 py-2.5 bg-[#2D5A27] text-white font-bold text-sm rounded-full shadow-md hover:bg-[#23471f] transition-colors"
            >
              Start Shopping Now
            </button>
          </div>
        ) : (
          /* Cart Items List */
          <div className="flex-1 overflow-y-auto p-4 space-y-3 divide-y divide-gray-100">
            {/* Delivery banner */}
            <div className="p-3 bg-[#F0FDF4] border border-[#4CAF50]/30 rounded-2xl flex items-center gap-3 text-xs text-[#2D5A27] font-semibold">
              <Truck className="w-5 h-5 text-[#F27D26] shrink-0" />
              <div>
                {subtotal >= 300 ? (
                  <span className="text-[#2D5A27] font-extrabold">🎉 FREE Delivery Unlocked for Dindigul!</span>
                ) : (
                  <span>
                    Add <strong className="text-[#F27D26]">₹{300 - subtotal}</strong> more for FREE Home Delivery!
                  </span>
                )}
              </div>
            </div>

            {cartItems.map((item) => (
              <div key={item.product.id} className="pt-3 flex items-center gap-3">
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="w-16 h-16 object-cover rounded-xl border border-gray-200 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-sm text-gray-900 truncate">{item.product.name}</h4>
                  <div className="text-xs text-gray-500">
                    ₹{item.product.price} / {item.product.unit}
                  </div>
                  <div className="text-xs font-bold text-[#F27D26] mt-0.5">
                    Subtotal: ₹{item.product.price * item.quantity}
                  </div>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center gap-1.5 bg-gray-100 p-1 rounded-xl">
                  <button
                    onClick={() => onUpdateQuantity(item.product.id, -1)}
                    className="w-6 h-6 rounded-lg bg-white text-gray-700 flex items-center justify-center font-bold text-xs hover:bg-gray-200"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="text-xs font-black text-gray-900 px-1">{item.quantity}</span>
                  <button
                    onClick={() => onUpdateQuantity(item.product.id, 1)}
                    className="w-6 h-6 rounded-lg bg-[#2D5A27] text-white flex items-center justify-center font-bold text-xs hover:bg-[#23471f]"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>

                {/* Delete button */}
                <button
                  onClick={() => onRemoveItem(item.product.id)}
                  className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                  title="Remove item"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Footer Checkout Summary */}
        {cartItems.length > 0 && !orderPlaced && (
          <div className="p-5 bg-gray-50 border-t border-gray-200 space-y-3">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-gray-600">
                <span>Items Subtotal</span>
                <span className="font-bold text-gray-900">₹{subtotal}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Estimated Home Delivery</span>
                <span className="font-bold text-gray-900">
                  {deliveryFee === 0 ? <span className="text-[#4CAF50]">FREE</span> : `₹${deliveryFee}`}
                </span>
              </div>
              <div className="flex justify-between text-sm font-extrabold text-[#2D5A27] pt-2 border-t border-gray-200">
                <span>Grand Total</span>
                <span className="text-[#F27D26] text-lg">₹{total}</span>
              </div>
            </div>

            {/* Quick Order Form Inputs */}
            <form onSubmit={handleCheckoutWhatsApp} className="space-y-2 pt-2">
              <input
                type="text"
                placeholder="Your Name (Optional)"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-white border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#4CAF50]"
              />
              <input
                type="tel"
                placeholder="Mobile Number for delivery call"
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-white border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#4CAF50]"
              />

              <button
                type="submit"
                id="cart-checkout-btn"
                className="w-full py-3 px-4 rounded-xl font-bold text-sm bg-[#25D366] hover:bg-[#20ba5a] text-white shadow-md transition-transform active:scale-95 flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-5 h-5 fill-white text-[#25D366]" />
                <span>Dispatch Order via WhatsApp</span>
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
