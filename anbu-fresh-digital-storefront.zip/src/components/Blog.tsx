import React, { useState } from 'react';
import { BLOGS } from '../data/blogs';
import { BlogPost } from '../types';
import { Calendar, Clock, User, Tag, ArrowRight, ArrowLeft, BookOpen, Share2 } from 'lucide-react';

export const Blog: React.FC = () => {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Header */}
      <div className="bg-[#2D5A27] text-white rounded-3xl p-8 sm:p-12 shadow-xl relative overflow-hidden">
        <div className="space-y-3 max-w-2xl">
          <span className="px-3 py-1 bg-[#F27D26] text-white font-extrabold text-xs uppercase tracking-wider rounded-full">
            Dindigul Nutrition & Health Guide
          </span>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
            Anbu Health & Produce Blog
          </h1>
          <p className="text-gray-100 text-sm sm:text-base leading-relaxed">
            Read expert dietary advice, fruit nutrition guides, and organic farming benefits curated by the Anbu Fruit & Vegetable Shop team.
          </p>
        </div>
      </div>

      {selectedPost ? (
        /* Full Article Reader View */
        <div className="bg-white rounded-3xl border border-gray-200 p-6 sm:p-12 shadow-sm space-y-8 animate-fadeIn">
          {/* Back button */}
          <button
            onClick={() => setSelectedPost(null)}
            id="blog-back-btn"
            className="inline-flex items-center gap-2 text-xs font-bold text-[#2D5A27] bg-[#F0FDF4] px-4 py-2 rounded-xl hover:bg-[#E1F9E6] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to All Articles
          </button>

          {/* Article Header */}
          <div className="space-y-4 max-w-4xl">
            <div className="flex flex-wrap gap-2">
              {selectedPost.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 bg-orange-50 text-[#F27D26] text-xs font-bold rounded-full border border-[#F27D26]/20"
                >
                  #{tag}
                </span>
              ))}
            </div>

            <h2 className="text-2xl sm:text-4xl font-extrabold text-[#2D5A27] leading-tight">
              {selectedPost.title}
            </h2>

            <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500 pt-2 border-t border-b border-gray-100 py-3">
              <span className="flex items-center gap-1.5 font-bold text-gray-800">
                <User className="w-4 h-4 text-[#4CAF50]" /> {selectedPost.author} ({selectedPost.authorRole})
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-gray-400" /> {selectedPost.date}
              </span>
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-gray-400" /> {selectedPost.readTime}
              </span>
            </div>
          </div>

          {/* Featured Image */}
          <div className="rounded-2xl overflow-hidden h-72 sm:h-[450px] bg-gray-100 shadow-sm border border-gray-100">
            <img
              src={selectedPost.featuredImage}
              alt={selectedPost.title}
              className="w-full h-full object-cover"
            />
          </div>

          {/* HTML Rich Content Body */}
          <div
            className="prose prose-green max-w-none text-gray-800 text-sm sm:text-base leading-relaxed space-y-4"
            dangerouslySetInnerHTML={{ __html: selectedPost.content }}
          />

          {/* Article Footer */}
          <div className="pt-8 border-t border-gray-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-gray-500 font-medium">
              Published by <strong>Anbu Fruit & Vegetable Shop</strong>, Balakrishnapuram, Dindigul.
            </div>

            <button
              onClick={() => setSelectedPost(null)}
              className="px-6 py-2.5 bg-[#2D5A27] text-white text-xs font-bold rounded-xl hover:bg-[#23471f] transition-colors"
            >
              Return to Blog Index
            </button>
          </div>
        </div>
      ) : (
        /* Blog List Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {BLOGS.map((post) => (
            <div
              key={post.id}
              className="bg-white rounded-3xl border border-gray-200 overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="relative h-60 bg-gray-100 overflow-hidden">
                  <img
                    src={post.featuredImage}
                    alt={post.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 right-3 px-3 py-1 bg-white/90 backdrop-blur-md text-[#2D5A27] text-xs font-extrabold rounded-full shadow-xs">
                    {post.readTime}
                  </div>
                </div>

                <div className="p-6 sm:p-8 space-y-3">
                  <div className="flex items-center gap-2 text-xs text-gray-400">
                    <Calendar className="w-3.5 h-3.5 text-[#F27D26]" /> {post.date}
                  </div>

                  <h3
                    onClick={() => setSelectedPost(post)}
                    className="text-xl font-extrabold text-[#2D5A27] hover:text-[#F27D26] cursor-pointer transition-colors leading-snug"
                  >
                    {post.title}
                  </h3>

                  <p className="text-gray-600 text-xs sm:text-sm line-clamp-3 leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>
              </div>

              <div className="p-6 sm:p-8 pt-0 flex items-center justify-between border-t border-gray-100 mt-2">
                <div className="text-xs font-bold text-gray-700">{post.author}</div>

                <button
                  onClick={() => setSelectedPost(post)}
                  id={`read-post-${post.id}`}
                  className="inline-flex items-center gap-1.5 text-xs font-black text-[#F27D26] hover:text-[#e06b17] transition-colors"
                >
                  <span>Read Full Article</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
