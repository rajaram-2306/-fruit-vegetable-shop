import React, { useState } from 'react';
import { PageType, Product } from '../types';
import { PRODUCTS } from '../data/products';
import { Leaf, ShoppingBag, Truck, ShieldCheck, Award, HeartHandshake, Phone, ArrowRight, Star, ChevronDown, Sparkles, Tag, CheckCircle2, MessageCircle } from 'lucide-react';

interface HomeProps {
  setCurrentPage: (page: PageType) => void;
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export const Home: React.FC<HomeProps> = ({
  setCurrentPage,
  onAddToCart,
  onSelectProduct,
}) => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [activeCategory, setActiveCategory] = useState<'all' | 'fruit' | 'vegetable' | 'organic'>('all');

  const featuredProducts = PRODUCTS.filter((p) => {
    if (activeCategory === 'all') return p.isPopular;
    return p.category === activeCategory;
  }).slice(0, 8);

  const testimonials = [
    {
      id: 1,
      name: 'R. Soundararajan',
      role: 'Resident, Balakrishnapuram',
      comment: 'Anbu shop delivers the freshest vegetables in Dindigul! Their small onions and country tomatoes arrive crisp every single morning. Best service in our locality.',
      rating: 5,
      location: 'Balakrishnapuram, Dindigul',
    },
    {
      id: 2,
      name: 'Priyadarshini K.',
      role: 'Home Chef & Mother',
      comment: 'I order organic keerais and seasonal fruits for my family regularly. Their prices are very honest compared to supermarket rates, and home delivery is always on time.',
      rating: 5,
      location: 'GTN Salai, Dindigul',
    },
    {
      id: 3,
      name: 'M. Selvakumar',
      role: 'Catering Owner',
      comment: 'We source bulk vegetables for marriage orders through Anbu shop. Their quality is top class and drumsticks, Ooty carrots are always fresh.',
      rating: 5,
      location: 'Dindigul Town',
    },
  ];

  const faqs = [
    {
      q: 'Where is Anbu Fruit & Vegetable Shop located in Dindigul?',
      a: 'We are conveniently located in Balakrishnapuram, Dindigul, Tamil Nadu. You can visit our store or call +91 94876 02371 for direct home delivery.',
    },
    {
      q: 'Do you offer home delivery in Balakrishnapuram and Dindigul?',
      a: 'Yes! We provide same-day express home delivery across Balakrishnapuram and nearby areas in Dindigul. Delivery is completely FREE for orders above ₹300.',
    },
    {
      q: 'Are your vegetables and fruits organically grown?',
      a: 'We offer a dedicated line of certified 100% pesticide-free organic vegetables, spinach (keerai), and seasonal fruits harvested directly from local farms near Dindigul and hill orchards.',
    },
    {
      q: 'Can I place bulk orders for functions, marriages, or catering?',
      a: 'Absolutely! We specialize in wholesale bulk orders for festivals, weddings, hotel supplies, and canteens at competitive wholesale market rates.',
    },
    {
      q: 'What are your store operating hours?',
      a: 'We are open 7 days a week from 7:00 AM in the morning to 9:00 PM in the evening for your daily fresh produce shopping.',
    },
  ];

  return (
    <div className="space-y-16 pb-12">
      {/* HERO BANNER SECTION */}
      <section className="relative min-h-[580px] lg:min-h-[640px] rounded-3xl overflow-hidden mx-4 sm:mx-6 lg:mx-8 shadow-2xl flex items-center mt-4">
        {/* Background Image with Gradient Overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1610348725531-843dff563e2c?auto=format&fit=crop&q=80&w=1600"
            alt="Anbu Fruit & Vegetable Shop Store"
            className="w-full h-full object-cover scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#2D5A27]/95 via-[#2D5A27]/80 to-black/40" />
        </div>

        {/* Hero Content Overlay */}
        <div className="relative z-10 max-w-4xl px-6 sm:px-10 lg:px-16 text-white py-12 space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F27D26] text-white font-bold text-xs uppercase tracking-wider shadow-md">
            <Sparkles className="w-3.5 h-3.5" /> Direct Farm Fresh • Balakrishnapuram, Dindigul
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight">
            Purely Fresh, <br />
            <span className="text-[#F27D26]">Naturally Picked Produce</span>
          </h1>

          <p className="text-gray-100 text-base sm:text-lg max-w-2xl leading-relaxed">
            Experience Dindigul’s finest selection of farm-fresh fruits, organic vegetables, and daily kitchen essentials. Sourced directly from local orchards every morning.
          </p>

          {/* Call-to-Action Buttons */}
          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={() => setCurrentPage('products')}
              id="hero-explore-btn"
              className="px-7 py-3.5 bg-[#F27D26] hover:bg-[#e06b17] text-white font-extrabold text-base rounded-full shadow-lg transition-transform active:scale-95 flex items-center gap-2"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>Explore All Products</span>
            </button>

            <a
              href="tel:+919487602371"
              id="hero-call-btn"
              className="px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white font-bold text-base rounded-full backdrop-blur-md border border-white/30 transition-colors flex items-center gap-2"
            >
              <Phone className="w-5 h-5 text-[#F27D26]" />
              <span>Call +91 94876 02371</span>
            </a>

            <button
              onClick={() => setCurrentPage('docs')}
              id="hero-mca-btn"
              className="px-5 py-3.5 bg-[#4CAF50] hover:bg-[#3d9140] text-white font-bold text-sm rounded-full shadow-md transition-colors"
            >
              MCA Project Docs
            </button>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-4 pt-6 border-t border-white/15 max-w-xl text-xs sm:text-sm">
            <div>
              <div className="text-2xl font-black text-[#F27D26]">100%</div>
              <div className="text-gray-200">Farm Fresh Daily</div>
            </div>
            <div>
              <div className="text-2xl font-black text-[#4CAF50]">7 AM - 9 PM</div>
              <div className="text-gray-200">Open All 7 Days</div>
            </div>
            <div>
              <div className="text-2xl font-black text-[#F27D26]">FREE</div>
              <div className="text-gray-200">Delivery over ₹300</div>
            </div>
          </div>
        </div>
      </section>

      {/* BUSINESS INTRODUCTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-8 sm:p-12 shadow-md border border-gray-100 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4">
            <div className="text-xs font-bold text-[#4CAF50] uppercase tracking-wider flex items-center gap-2">
              <Leaf className="w-4 h-4" /> Welcome to Anbu Fruit & Vegetable Shop
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-[#2D5A27]">
              Serving Balakrishnapuram, Dindigul with Health & Quality
            </h2>
            <p className="text-gray-600 leading-relaxed text-sm sm:text-base">
              At <strong>Anbu Fruit & Vegetable Shop</strong>, we take immense pride in bringing wholesome nutrition to your doorstep. Located in the heart of Balakrishnapuram, Dindigul, Tamil Nadu, we work hand-in-hand with local farmers around Dindigul, Ooty, and Kodaikanal to deliver crisp vegetables, juicy fruits, and chemical-free organic greens.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-gray-800 bg-gray-50 p-3 rounded-xl border border-gray-100">
                <CheckCircle2 className="w-5 h-5 text-[#4CAF50]" />
                <span>Zero Cold-Storage Delays</span>
              </div>
              <div className="flex items-center gap-2 text-sm font-semibold text-gray-800 bg-gray-50 p-3 rounded-xl border border-gray-100">
                <CheckCircle2 className="w-5 h-5 text-[#4CAF50]" />
                <span>Handpicked Quality Check</span>
              </div>
              <div className="flex items-center gap-2 text-sm font-semibold text-gray-800 bg-gray-50 p-3 rounded-xl border border-gray-100">
                <CheckCircle2 className="w-5 h-5 text-[#4CAF50]" />
                <span>Fair Market Prices</span>
              </div>
              <div className="flex items-center gap-2 text-sm font-semibold text-gray-800 bg-gray-50 p-3 rounded-xl border border-gray-100">
                <CheckCircle2 className="w-5 h-5 text-[#4CAF50]" />
                <span>Prompt Local Home Delivery</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <div className="rounded-2xl overflow-hidden shadow-xl border-4 border-white">
              <img
                src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80"
                alt="Fresh Organic Vegetables Basket"
                className="w-full h-72 sm:h-80 object-cover"
              />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-[#2D5A27] text-white p-4 rounded-2xl shadow-lg text-xs font-bold space-y-1">
              <div className="text-[#F27D26] font-extrabold text-sm">Direct Farm Picked</div>
              <div>Balakrishnapuram, Dindigul</div>
            </div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <span className="text-xs font-bold text-[#F27D26] uppercase tracking-wider">Unmatched Promise</span>
          <h2 className="text-3xl font-extrabold text-[#2D5A27]">Why Choose Anbu Fresh?</h2>
          <p className="text-gray-600 text-sm">Four reasons why households across Dindigul trust our daily produce.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow space-y-3">
            <div className="w-12 h-12 rounded-xl bg-[#F0FDF4] text-[#4CAF50] flex items-center justify-center font-bold">
              <Leaf className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-lg text-gray-900">100% Farm Fresh</h3>
            <p className="text-gray-500 text-xs leading-relaxed">
              Harvested at dawn and displayed at our store by 7 AM. Zero stale inventory.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow space-y-3">
            <div className="w-12 h-12 rounded-xl bg-orange-50 text-[#F27D26] flex items-center justify-center font-bold">
              <Truck className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-lg text-gray-900">Express Delivery</h3>
            <p className="text-gray-500 text-xs leading-relaxed">
              Doorstep grocery delivery across Balakrishnapuram and Dindigul town within hours.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow space-y-3">
            <div className="w-12 h-12 rounded-xl bg-[#F0FDF4] text-[#2D5A27] flex items-center justify-center font-bold">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-lg text-gray-900">Organic Produce</h3>
            <p className="text-gray-500 text-xs leading-relaxed">
              Chemical pesticide-free greens and hill-station vegetables for family wellness.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow space-y-3">
            <div className="w-12 h-12 rounded-xl bg-orange-50 text-[#F27D26] flex items-center justify-center font-bold">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-lg text-gray-900">Best Wholesale Rates</h3>
            <p className="text-gray-500 text-xs leading-relaxed">
              Honest transparent pricing for retail shoppers and special rates for bulk function orders.
            </p>
          </div>
        </div>
      </section>

      {/* FEATURED PRODUCTS & CATEGORY TABS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold text-[#4CAF50] uppercase tracking-wider">Top Harvest</span>
            <h2 className="text-3xl font-extrabold text-[#2D5A27]">Featured Daily Produce</h2>
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-wrap items-center gap-2 bg-white p-1.5 rounded-2xl border border-gray-200 shadow-xs">
            {(
              [
                { id: 'all', label: 'All Featured' },
                { id: 'fruit', label: 'Fresh Fruits' },
                { id: 'vegetable', label: 'Vegetables' },
                { id: 'organic', label: 'Organic Greens' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id)}
                id={`home-tab-${tab.id}`}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                  activeCategory === tab.id
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
            >
              <div
                className="relative cursor-pointer overflow-hidden bg-gray-50 h-48"
                onClick={() => onSelectProduct(product)}
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 left-3 flex flex-col gap-1">
                  {product.isOrganic && (
                    <span className="px-2.5 py-0.5 bg-[#2D5A27] text-white text-[10px] font-extrabold rounded-full">
                      Organic
                    </span>
                  )}
                  {product.isPopular && (
                    <span className="px-2.5 py-0.5 bg-[#F27D26] text-white text-[10px] font-extrabold rounded-full">
                      Popular
                    </span>
                  )}
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <div className="text-[11px] font-bold text-[#4CAF50] uppercase tracking-wider">
                    {product.category} • {product.origin}
                  </div>
                  <h3
                    onClick={() => onSelectProduct(product)}
                    className="font-bold text-base text-gray-900 group-hover:text-[#2D5A27] cursor-pointer transition-colors line-clamp-1"
                  >
                    {product.name}
                  </h3>
                  <p className="text-gray-500 text-xs line-clamp-2 mt-1">{product.description}</p>
                </div>

                <div className="pt-2 border-t border-gray-100 flex items-center justify-between gap-2">
                  <div>
                    <span className="text-lg font-black text-[#F27D26]">₹{product.price}</span>
                    <span className="text-xs text-gray-500 font-medium"> / {product.unit}</span>
                  </div>

                  <button
                    onClick={() => onAddToCart(product)}
                    id={`add-cart-${product.id}`}
                    className="px-3 py-2 bg-[#2D5A27] hover:bg-[#23471f] text-white font-bold text-xs rounded-xl shadow-xs transition-transform active:scale-95 flex items-center gap-1.5"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" /> Add
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center pt-4">
          <button
            onClick={() => setCurrentPage('products')}
            id="home-view-all-products"
            className="px-8 py-3 bg-white text-[#2D5A27] border-2 border-[#2D5A27] font-extrabold text-sm rounded-full hover:bg-[#2D5A27] hover:text-white transition-colors inline-flex items-center gap-2 shadow-sm"
          >
            <span>View Full Catalog & Wholesale Services</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* WEEKLY SPECIAL PROMOTION BOX */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-[#F27D26] to-[#e06b17] rounded-3xl p-8 sm:p-12 text-white shadow-xl relative overflow-hidden flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="space-y-3 max-w-xl z-10">
            <span className="px-3 py-1 bg-white/20 text-white font-black text-xs uppercase tracking-wider rounded-full backdrop-blur-xs">
              ⚡ Special Festival Season Offer
            </span>
            <h2 className="text-3xl sm:text-5xl font-black leading-tight">
              Get Up To 20% OFF On Bulk Vegetable & Fruit Baskets!
            </h2>
            <p className="text-white/90 text-sm sm:text-base leading-relaxed">
              Planning a temple puja, family function, or festival celebration in Dindigul? Order custom festival fruit hampers and bulk vegetable packs with free home delivery.
            </p>
          </div>

          <div className="z-10 shrink-0 space-y-3 text-center sm:text-left">
            <a
              href="https://wa.me/919487602371?text=Hello%20Anbu%20Shop,%20I%20want%20to%20claim%20the%20Festival%20Offer%20discount."
              target="_blank"
              rel="noopener noreferrer"
              id="claim-offer-btn"
              className="px-8 py-4 bg-white text-[#F27D26] font-black text-base rounded-full shadow-2xl hover:bg-gray-100 transition-transform active:scale-95 inline-flex items-center gap-2"
            >
              <Tag className="w-5 h-5 text-[#F27D26]" /> Claim Offer on WhatsApp
            </a>
            <div className="text-xs text-white/80">Valid for Balakrishnapuram & Dindigul orders</div>
          </div>
        </div>
      </section>

      {/* CUSTOMER TESTIMONIALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center max-w-xl mx-auto">
          <span className="text-xs font-bold text-[#4CAF50] uppercase tracking-wider">Local Reviews</span>
          <h2 className="text-3xl font-extrabold text-[#2D5A27]">What Dindigul Customers Say</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center gap-1 text-[#F27D26]">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#F27D26]" />
                  ))}
                </div>
                <p className="text-gray-700 text-sm italic leading-relaxed">"{t.comment}"</p>
              </div>

              <div className="pt-3 border-t border-gray-100">
                <div className="font-bold text-gray-900 text-sm">{t.name}</div>
                <div className="text-xs text-[#4CAF50] font-medium">{t.role}</div>
                <div className="text-[11px] text-gray-400">{t.location}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ ACCORDION */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center">
          <span className="text-xs font-bold text-[#F27D26] uppercase tracking-wider">Got Questions?</span>
          <h2 className="text-3xl font-extrabold text-[#2D5A27]">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-xs transition-colors"
            >
              <button
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                id={`faq-btn-${idx}`}
                className="w-full p-5 text-left font-bold text-gray-900 flex items-center justify-between gap-4 focus:outline-none"
              >
                <span className="text-sm sm:text-base">{faq.q}</span>
                <ChevronDown
                  className={`w-5 h-5 text-[#2D5A27] transition-transform duration-200 ${
                    openFaq === idx ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openFaq === idx && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-gray-600 border-t border-gray-100 leading-relaxed bg-gray-50/50">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
