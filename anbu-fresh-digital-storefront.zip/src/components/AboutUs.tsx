import React from 'react';
import { PageType } from '../types';
import { Leaf, Award, ShieldCheck, HeartHandshake, MapPin, Users, CheckCircle, Target, Eye, Sparkles } from 'lucide-react';

interface AboutUsProps {
  setCurrentPage: (page: PageType) => void;
}

export const AboutUs: React.FC<AboutUsProps> = ({ setCurrentPage }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* Header Banner */}
      <div className="bg-[#2D5A27] text-white rounded-3xl p-8 sm:p-12 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-3xl space-y-4">
          <span className="px-3 py-1 bg-[#F27D26] text-white font-extrabold text-xs uppercase tracking-wider rounded-full">
            Our Heritage & Commitment
          </span>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
            About Anbu Fruit & Vegetable Shop
          </h1>
          <p className="text-gray-100 text-sm sm:text-base leading-relaxed">
            Delivering farm-fresh freshness, chemical-free organic greens, and honest service to households across Balakrishnapuram, Dindigul since establishment.
          </p>
        </div>
      </div>

      {/* STORY & HERITAGE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        <div className="lg:col-span-6 space-y-4">
          <div className="text-xs font-bold text-[#4CAF50] uppercase tracking-wider flex items-center gap-1.5">
            <Leaf className="w-4 h-4 text-[#F27D26]" /> Our Roots & Beginnings
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-[#2D5A27]">
            From Local Village Orchards to Your Kitchen Table
          </h2>
          <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
            <strong>Anbu Fruit & Vegetable Shop</strong> was founded with a simple, genuine purpose: to remove artificial middle layers between hard-working rural farmers in Dindigul district and local households seeking unadulterated nutrition.
          </p>
          <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
            Located in <strong>Balakrishnapuram, Dindigul, Tamil Nadu</strong>, our store has built a strong reputation over the years. Every morning at 5 AM, our team personally selects the top harvest from local farms near Balakrishnapuram, Ooty hill stations, and Salem orchards. We ensure that every tomato, banana, and bundle of keerai reaches your family in its purest, crispest state.
          </p>
        </div>

        <div className="lg:col-span-6 relative">
          <div className="rounded-3xl overflow-hidden shadow-xl border-4 border-white">
            <img
              src="https://images.unsplash.com/photo-1610348725531-843dff563e2c?auto=format&fit=crop&w=1000&q=80"
              alt="Anbu Shop Produce Selection"
              className="w-full h-80 sm:h-96 object-cover"
            />
          </div>
          <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-2xl shadow-xl border border-gray-100 hidden sm:block max-w-xs">
            <div className="text-2xl font-black text-[#F27D26]">100% Guaranteed</div>
            <div className="text-xs text-gray-600 font-medium mt-1">
              Freshness & weight accuracy on every purchase at Balakrishnapuram store.
            </div>
          </div>
        </div>
      </div>

      {/* MISSION, VISION & CORE VALUES */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#F0FDF4] text-[#2D5A27] flex items-center justify-center">
            <Target className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-extrabold text-[#2D5A27]">Our Mission</h3>
          <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
            To make farm-fresh, affordable, and pesticide-free fruits and vegetables accessible to every family in Balakrishnapuram and Dindigul, while empowering local farming communities through fair pricing.
          </p>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-orange-50 text-[#F27D26] flex items-center justify-center">
            <Eye className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-extrabold text-[#2D5A27]">Our Vision</h3>
          <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
            To be recognized as Dindigul’s most trusted, health-conscious retail produce destination and online delivery service, setting high standards for hygiene, organic quality, and customer satisfaction.
          </p>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#F0FDF4] text-[#4CAF50] flex items-center justify-center">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-extrabold text-[#2D5A27]">Core Values</h3>
          <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
            Uncompromising freshness, honest weight measurement, direct farmer sourcing, eco-friendly handling, and dedicated customer relationship management.
          </p>
        </div>
      </div>

      {/* OWNER'S MESSAGE */}
      <div className="bg-[#F8FAF8] rounded-3xl p-8 sm:p-12 border border-[#4CAF50]/30 shadow-xs grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        <div className="md:col-span-4 flex flex-col items-center text-center space-y-3">
          <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-[#2D5A27] shadow-md">
            <img
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80"
              alt="Owner Anbu"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h4 className="font-extrabold text-lg text-[#2D5A27]">Mr. Anbuselvan</h4>
            <div className="text-xs text-[#F27D26] font-bold">Founder & Proprieter</div>
            <div className="text-[11px] text-gray-500">Anbu Fruit & Vegetable Shop, Dindigul</div>
          </div>
        </div>

        <div className="md:col-span-8 space-y-3">
          <span className="text-xs font-bold text-[#4CAF50] uppercase tracking-wider">A Message from the Owner</span>
          <h3 className="text-2xl font-extrabold text-[#2D5A27]">
            "Your Family's Health is Our Greatest Privilege"
          </h3>
          <p className="text-gray-700 text-sm leading-relaxed italic">
            "When we opened our shop doors in Balakrishnapuram, our promise was clear: we will only sell produce that we would confidently feed our own children. Every piece of fruit and every vegetable that leaves our counter undergoes thorough inspection. We thank all our loyal Dindigul customers for trusting us every morning."
          </p>
          <div className="pt-2 text-xs font-bold text-gray-800">
            Contact Owner Direct: <a href="tel:+919487602371" className="text-[#F27D26] underline">+91 94876 02371</a>
          </div>
        </div>
      </div>

      {/* WHY CUSTOMERS TRUST US & BUSINESS HIGHLIGHTS */}
      <div className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold text-[#F27D26] uppercase tracking-wider">Key Highlights</span>
          <h2 className="text-3xl font-extrabold text-[#2D5A27]">Why Customers Trust Anbu Shop</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-xs space-y-2">
            <div className="text-3xl font-black text-[#2D5A27]">100+</div>
            <div className="font-bold text-gray-900 text-sm">Daily Fresh Items</div>
            <p className="text-gray-500 text-xs">Wide variety of fruits, root vegetables, greens, and cooking staples.</p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-xs space-y-2">
            <div className="text-3xl font-black text-[#F27D26]">5,000+</div>
            <div className="font-bold text-gray-900 text-sm">Happy Families</div>
            <p className="text-gray-500 text-xs">Serving residents across Balakrishnapuram and Dindigul town daily.</p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-xs space-y-2">
            <div className="text-3xl font-black text-[#4CAF50]">0 Hours</div>
            <div className="font-bold text-gray-900 text-sm">Cold Storage Delay</div>
            <p className="text-gray-500 text-xs">Fresh farm harvest brought directly to customer counter every morning.</p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-xs space-y-2">
            <div className="text-3xl font-black text-[#2D5A27]">7 Days</div>
            <div className="font-bold text-gray-900 text-sm">Store Operation</div>
            <p className="text-gray-500 text-xs">Open 7:00 AM to 9:00 PM non-stop for convenience.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
