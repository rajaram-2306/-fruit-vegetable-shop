import React, { useState, useEffect } from 'react';
import { PageType } from '../types';
import { ShoppingBag, Phone, Menu, X, Leaf, Award, Sparkles, MessageCircle } from 'lucide-react';

interface NavbarProps {
  currentPage: PageType;
  setCurrentPage: (page: PageType) => void;
  cartCount: number;
  onOpenCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  setCurrentPage,
  cartCount,
  onOpenCart,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { id: PageType; label: string; badge?: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'products', label: 'Products & Services' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'blog', label: 'Blog & Health' },
    { id: 'contact', label: 'Contact Us' },
    { id: 'docs', label: 'MCA Project Docs', badge: 'MCA' },
  ];

  const handleNavClick = (page: PageType) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-md py-3 border-b border-gray-200'
          : 'bg-white py-4 border-b border-gray-100'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2 group text-left focus:outline-none"
            id="nav-logo-btn"
          >
            <div className="w-10 h-10 rounded-xl bg-[#2D5A27] text-white flex items-center justify-center shadow-md group-hover:scale-105 transition-transform duration-200">
              <Leaf className="w-6 h-6 text-[#F27D26]" />
            </div>
            <div>
              <div className="font-extrabold text-xl sm:text-2xl tracking-tight text-[#2D5A27]">
                ANBU <span className="text-[#F27D26]">FRESH</span>
              </div>
              <div className="text-[10px] text-gray-500 font-medium tracking-wider uppercase -mt-1 hidden sm:block">
                Fruit & Vegetable Shop • Balakrishnapuram, Dindigul
              </div>
            </div>
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => {
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  id={`nav-link-${item.id}`}
                  className={`px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 relative flex items-center gap-1.5 ${
                    isActive
                      ? 'text-[#2D5A27] bg-[#F0FDF4] shadow-xs'
                      : 'text-gray-700 hover:text-[#2D5A27] hover:bg-gray-50'
                  }`}
                >
                  {item.label}
                  {item.badge && (
                    <span className="px-1.5 py-0.5 text-[10px] font-bold bg-[#F27D26] text-white rounded-full">
                      {item.badge}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-3 right-3 h-0.5 bg-[#4CAF50] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Header Right Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Phone quick link */}
            <a
              href="tel:+919487602371"
              id="header-phone-link"
              className="hidden md:flex items-center gap-2 px-3 py-2 rounded-full text-xs font-bold text-[#2D5A27] bg-[#F0FDF4] hover:bg-[#E1F9E6] border border-[#4CAF50]/30 transition-colors"
              title="Call Store Now"
            >
              <Phone className="w-3.5 h-3.5 text-[#F27D26]" />
              <span>+91 94876 02371</span>
            </a>

            {/* WhatsApp Quick Order Button */}
            <a
              href="https://wa.me/919487602371?text=Hello%20Anbu%20Fruit%20%26%20Vegetable%20Shop,%20I%20would%20like%20to%20order%20fresh%20fruits/vegetables."
              target="_blank"
              rel="noopener noreferrer"
              id="header-whatsapp-btn"
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-bold text-white bg-[#25D366] hover:bg-[#20ba5a] shadow-xs transition-transform active:scale-95"
            >
              <MessageCircle className="w-4 h-4 fill-white text-[#25D366]" />
              <span className="hidden xl:inline">WhatsApp Order</span>
            </a>

            {/* Cart Drawer Trigger */}
            <button
              onClick={onOpenCart}
              id="header-cart-btn"
              className="relative p-2.5 rounded-full text-gray-700 hover:text-[#2D5A27] hover:bg-gray-100 transition-colors border border-gray-200"
              aria-label="View Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5 text-[#2D5A27]" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#F27D26] text-white text-xs font-bold rounded-full flex items-center justify-center shadow-sm animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              id="mobile-menu-toggle"
              className="lg:hidden p-2.5 rounded-xl text-gray-700 hover:bg-gray-100 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6 text-[#2D5A27]" /> : <Menu className="w-6 h-6 text-[#2D5A27]" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-gray-100 shadow-xl px-4 pt-3 pb-6 space-y-2 animate-fadeIn">
          <div className="text-xs font-semibold text-[#2D5A27] uppercase tracking-wider px-3 pt-1 pb-1">
            Navigation Menu
          </div>
          {navItems.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                id={`mobile-nav-link-${item.id}`}
                className={`w-full text-left px-4 py-2.5 rounded-xl text-base font-semibold flex items-center justify-between transition-colors ${
                  isActive
                    ? 'text-[#2D5A27] bg-[#F0FDF4] font-bold border-l-4 border-[#4CAF50]'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <span>{item.label}</span>
                {item.badge && (
                  <span className="px-2 py-0.5 text-xs font-bold bg-[#F27D26] text-white rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-3 border-t border-gray-100 space-y-2">
            <a
              href="tel:+919487602371"
              id="mobile-call-btn"
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#F0FDF4] text-[#2D5A27] font-bold text-sm border border-[#4CAF50]/30"
            >
              <Phone className="w-4 h-4 text-[#F27D26]" />
              Call Store: +91 94876 02371
            </a>
            <a
              href="https://wa.me/919487602371?text=Hello%20Anbu%20Fruit%20%26%20Vegetable%20Shop,%20I%20would%20like%20to%20order."
              target="_blank"
              rel="noopener noreferrer"
              id="mobile-whatsapp-btn"
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#25D366] text-white font-bold text-sm"
            >
              <MessageCircle className="w-4 h-4" />
              Order on WhatsApp
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
