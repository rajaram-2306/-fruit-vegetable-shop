import React from 'react';
import { Product } from '../types';
import { X, ShoppingBag, CheckCircle, MapPin, Sparkles, Phone, MessageCircle } from 'lucide-react';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  onBuyNow: (product: Product) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
}) => {
  if (!product) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-gray-100 relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          id="modal-close-btn"
          className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-white/80 hover:bg-white text-gray-700 shadow-md flex items-center justify-center transition-transform hover:scale-110"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Image Column */}
          <div className="relative h-64 md:h-full min-h-[260px] bg-gray-50">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute top-4 left-4 flex flex-col gap-1.5">
              {product.isOrganic && (
                <span className="px-3 py-1 bg-[#2D5A27] text-white text-xs font-extrabold rounded-full shadow-sm">
                  100% Organic
                </span>
              )}
              {product.isPopular && (
                <span className="px-3 py-1 bg-[#F27D26] text-white text-xs font-extrabold rounded-full shadow-sm">
                  ★ Best Seller
                </span>
              )}
            </div>
          </div>

          {/* Details Column */}
          <div className="p-6 md:p-8 flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold text-[#4CAF50] uppercase tracking-wider mb-1">
                {product.category.toUpperCase()} • {product.stockStatus}
              </div>
              <h2 className="text-2xl font-extrabold text-[#2D5A27] mb-2">{product.name}</h2>

              {/* Price */}
              <div className="flex items-baseline gap-2 mb-4">
                <span className="text-3xl font-black text-[#F27D26]">₹{product.price}</span>
                <span className="text-sm font-semibold text-gray-500">/ {product.unit}</span>
              </div>

              {/* Description */}
              <p className="text-gray-600 text-sm leading-relaxed mb-4">
                {product.description}
              </p>

              {/* Origin */}
              {product.origin && (
                <div className="flex items-center gap-2 text-xs font-medium text-gray-600 bg-gray-50 p-2.5 rounded-xl border border-gray-200/60 mb-4">
                  <MapPin className="w-4 h-4 text-[#2D5A27]" />
                  <span>Direct Farm Source: <strong className="text-gray-900">{product.origin}</strong></span>
                </div>
              )}

              {/* Benefits */}
              {product.benefits && product.benefits.length > 0 && (
                <div className="mb-6">
                  <div className="text-xs font-bold text-gray-900 uppercase tracking-wider mb-2 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#F27D26]" /> Health Benefits
                  </div>
                  <ul className="space-y-1.5">
                    {product.benefits.map((b, idx) => (
                      <li key={idx} className="text-xs text-gray-600 flex items-center gap-2">
                        <CheckCircle className="w-3.5 h-3.5 text-[#4CAF50] shrink-0" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-4 border-t border-gray-100">
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    onAddToCart(product);
                  }}
                  id="modal-add-to-cart-btn"
                  className="w-full py-3 px-4 rounded-xl font-bold text-sm bg-[#F0FDF4] text-[#2D5A27] border border-[#4CAF50]/40 hover:bg-[#E1F9E6] transition-colors flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4 text-[#2D5A27]" />
                  Add to Cart
                </button>
                <button
                  onClick={() => {
                    onBuyNow(product);
                  }}
                  id="modal-buy-now-btn"
                  className="w-full py-3 px-4 rounded-xl font-bold text-sm bg-[#F27D26] hover:bg-[#e06b17] text-white shadow-md transition-transform active:scale-95 flex items-center justify-center gap-2"
                >
                  Buy Now
                </button>
              </div>

              <a
                href={`https://wa.me/919487602371?text=Hello%20Anbu%20Shop,%20I%20want%20to%20order%20${encodeURIComponent(product.name)}%20(₹${product.price}/${product.unit})`}
                target="_blank"
                rel="noopener noreferrer"
                id="modal-whatsapp-direct"
                className="w-full py-2.5 rounded-xl text-xs font-bold bg-[#25D366] text-white flex items-center justify-center gap-2 hover:bg-[#20ba5a] transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                Quick Order via WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
