import React, { useState } from 'react';
import { PageType } from '../types';
import { Leaf, MapPin, Phone, Clock, Mail, Facebook, Instagram, Youtube, MessageCircle, ArrowUp, CheckCircle, Send } from 'lucide-react';

interface FooterProps {
  setCurrentPage: (page: PageType) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentPage }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNav = (page: PageType) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#2D5A27] text-white pt-16 pb-8 border-t-4 border-[#F27D26] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-white/10">
          {/* Column 1: Brand & About */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-white text-[#2D5A27] flex items-center justify-center font-black">
                <Leaf className="w-6 h-6 text-[#F27D26]" />
              </div>
              <span className="font-extrabold text-2xl tracking-tight text-white">
                ANBU <span className="text-[#F27D26]">FRESH</span>
              </span>
            </div>
            <p className="text-gray-200 text-sm leading-relaxed">
              Your premier local fruit and vegetable store in Balakrishnapuram, Dindigul. Delivering farm-fresh produce, 100% organic greens, and daily grocery items directly to your home.
            </p>
            <div className="pt-2 flex items-center gap-3">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                id="footer-facebook"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-[#F27D26] flex items-center justify-center transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4 text-white" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                id="footer-instagram"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-[#F27D26] flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4 text-white" />
              </a>
              <a
                href="https://wa.me/919487602371"
                target="_blank"
                rel="noreferrer"
                id="footer-whatsapp"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-[#25D366] flex items-center justify-center transition-colors"
                aria-label="WhatsApp"
              >
                <MessageCircle className="w-4 h-4 text-white" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                id="footer-youtube"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-[#FF0000] flex items-center justify-center transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4 text-white" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white border-l-4 border-[#F27D26] pl-3">Quick Navigation</h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => handleNav('home')} id="footer-link-home" className="hover:text-[#F27D26] transition-colors flex items-center gap-2">
                  <span className="text-[#F27D26]">›</span> Home
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} id="footer-link-about" className="hover:text-[#F27D26] transition-colors flex items-center gap-2">
                  <span className="text-[#F27D26]">›</span> About Us & Heritage
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('products')} id="footer-link-products" className="hover:text-[#F27D26] transition-colors flex items-center gap-2">
                  <span className="text-[#F27D26]">›</span> Products & Services
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('gallery')} id="footer-link-gallery" className="hover:text-[#F27D26] transition-colors flex items-center gap-2">
                  <span className="text-[#F27D26]">›</span> Photo Gallery
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('blog')} id="footer-link-blog" className="hover:text-[#F27D26] transition-colors flex items-center gap-2">
                  <span className="text-[#F27D26]">›</span> Health Blog & Tips
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} id="footer-link-contact" className="hover:text-[#F27D26] transition-colors flex items-center gap-2">
                  <span className="text-[#F27D26]">›</span> Contact & Location Map
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('docs')} id="footer-link-docs" className="text-[#4CAF50] font-bold hover:text-white transition-colors flex items-center gap-2">
                  <span className="text-[#F27D26]">›</span> MCA Project Documentation
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Contact & Store Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white border-l-4 border-[#F27D26] pl-3">Store Location & Hours</h3>
            <div className="space-y-3 text-sm text-gray-200">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#F27D26] shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-white">Anbu Fruit & Vegetable Shop</div>
                  <div>Balakrishnapuram, Dindigul</div>
                  <div>Tamil Nadu, India</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-[#F27D26] shrink-0" />
                <a href="tel:+919487602371" className="hover:underline font-bold text-white">
                  +91 94876 02371
                </a>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-[#F27D26] shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-white">Business Hours</div>
                  <div>Monday – Sunday</div>
                  <div className="text-[#4CAF50] font-semibold">7:00 AM – 9:00 PM (All 7 Days)</div>
                </div>
              </div>
            </div>
          </div>

          {/* Column 4: Newsletter & Daily Offers */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white border-l-4 border-[#F27D26] pl-3">Daily Deals Newsletter</h3>
            <p className="text-sm text-gray-200">
              Subscribe to receive morning farm arrival alerts and special discounts on fresh organic produce in Dindigul.
            </p>
            {subscribed ? (
              <div className="p-3 bg-[#4CAF50]/20 border border-[#4CAF50] rounded-xl flex items-center gap-2 text-sm text-white font-medium">
                <CheckCircle className="w-5 h-5 text-[#4CAF50]" />
                <span>Subscribed! You will receive daily fresh updates.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <div className="relative">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email address"
                    required
                    id="footer-newsletter-email"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/10 text-white placeholder-gray-300 border border-white/20 focus:outline-none focus:ring-2 focus:ring-[#F27D26] text-sm"
                  />
                  <button
                    type="submit"
                    id="footer-newsletter-submit"
                    className="absolute right-1 top-1 bottom-1 px-3 bg-[#F27D26] hover:bg-[#e06b17] text-white rounded-lg flex items-center justify-center transition-colors"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-[11px] text-gray-300">We respect your privacy. Zero spam guaranteed.</div>
              </form>
            )}
          </div>
        </div>

        {/* Bottom Bar & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-gray-300">
          <div>
            © {new Date().getFullYear()} <span className="font-bold text-white">Anbu Fruit & Vegetable Shop</span>. All rights reserved.
            <span className="block sm:inline sm:ml-2 text-gray-400">Balakrishnapuram, Dindigul, Tamil Nadu.</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="px-2.5 py-1 bg-white/10 rounded-full font-mono text-[11px] text-[#4CAF50]">
              MCA Final Year Project Template
            </span>
            <button
              onClick={scrollToTop}
              id="back-to-top-btn"
              className="p-2 rounded-full bg-white/10 hover:bg-[#F27D26] text-white transition-colors"
              title="Scroll back to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
