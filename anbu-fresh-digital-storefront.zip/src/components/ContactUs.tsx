import React, { useState } from 'react';
import { ContactFormData } from '../types';
import { MapPin, Phone, Clock, Mail, MessageCircle, Send, CheckCircle2, Facebook, Instagram, Youtube, AlertCircle } from 'lucide-react';

export const ContactUs: React.FC = () => {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    mobile: '',
    email: '',
    subject: 'General Inquiry',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setErrorMessage('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!formData.name.trim() || !formData.mobile.trim() || !formData.message.trim()) {
      setErrorMessage('Please fill in your Name, Mobile Number, and Message.');
      return;
    }

    if (formData.mobile.length < 10) {
      setErrorMessage('Please enter a valid 10-digit Indian mobile number.');
      return;
    }

    // Success response
    setSubmitted(true);
    setErrorMessage('');
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        name: '',
        mobile: '',
        email: '',
        subject: 'General Inquiry',
        message: '',
      });
    }, 6000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Header Banner */}
      <div className="bg-[#2D5A27] text-white rounded-3xl p-8 sm:p-12 shadow-xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-3 max-w-2xl">
          <span className="px-3 py-1 bg-[#F27D26] text-white font-extrabold text-xs uppercase tracking-wider rounded-full">
            We Are Here To Help
          </span>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
            Contact Anbu Fruit & Vegetable Shop
          </h1>
          <p className="text-gray-100 text-sm sm:text-base leading-relaxed">
            Have questions about daily fresh farm deliveries, organic keerais, or bulk marriage catering orders in Dindigul? Get in touch with us!
          </p>
        </div>

        <a
          href="tel:+919487602371"
          id="contact-call-now-btn"
          className="px-6 py-3.5 bg-[#F27D26] hover:bg-[#e06b17] text-white font-black text-sm rounded-full shadow-lg shrink-0 flex items-center gap-2"
        >
          <Phone className="w-4 h-4" /> Call +91 94876 02371
        </a>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left Column: Store Details & Map */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
            <h2 className="text-2xl font-extrabold text-[#2D5A27]">Store Details</h2>

            <div className="space-y-4 text-sm">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#F0FDF4] text-[#2D5A27] flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-extrabold text-gray-900">Store Address</div>
                  <div className="text-gray-600 leading-relaxed mt-0.5">
                    Anbu Fruit & Vegetable Shop, <br />
                    Balakrishnapuram, Dindigul, <br />
                    Tamil Nadu – 624005, India.
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#F27D26] flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-extrabold text-gray-900">Direct Phone Contact</div>
                  <a href="tel:+919487602371" className="text-[#F27D26] font-bold text-base hover:underline block mt-0.5">
                    +91 94876 02371
                  </a>
                  <div className="text-xs text-gray-400">Call for daily stock & price inquiry</div>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#F0FDF4] text-[#4CAF50] flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-extrabold text-gray-900">Working Hours</div>
                  <div className="text-gray-700 font-semibold mt-0.5">Monday to Sunday</div>
                  <div className="text-[#2D5A27] font-bold">7:00 AM – 9:00 PM (Open All 7 Days)</div>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-green-50 text-[#25D366] flex items-center justify-center shrink-0">
                  <MessageCircle className="w-5 h-5 fill-[#25D366]" />
                </div>
                <div>
                  <div className="font-extrabold text-gray-900">WhatsApp Instant Chat</div>
                  <a
                    href="https://wa.me/919487602371?text=Hello%20Anbu%20Shop,%20I%20have%20an%20inquiry."
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#25D366] font-bold text-sm hover:underline block mt-0.5"
                  >
                    Click to Chat on WhatsApp
                  </a>
                </div>
              </div>
            </div>

            {/* Social Connect */}
            <div className="pt-4 border-t border-gray-100">
              <div className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Connect With Us</div>
              <div className="flex items-center gap-3">
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noreferrer"
                  id="contact-fb"
                  className="p-3 bg-gray-100 hover:bg-[#2D5A27] hover:text-white text-gray-700 rounded-xl transition-colors"
                >
                  <Facebook className="w-5 h-5" />
                </a>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noreferrer"
                  id="contact-ig"
                  className="p-3 bg-gray-100 hover:bg-[#F27D26] hover:text-white text-gray-700 rounded-xl transition-colors"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a
                  href="https://youtube.com"
                  target="_blank"
                  rel="noreferrer"
                  id="contact-yt"
                  className="p-3 bg-gray-100 hover:bg-[#FF0000] hover:text-white text-gray-700 rounded-xl transition-colors"
                >
                  <Youtube className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* Embedded Google Maps */}
          <div className="bg-white p-3 rounded-3xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="text-xs font-bold text-[#2D5A27] p-2 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[#F27D26]" /> Google Maps Location: Balakrishnapuram, Dindigul
            </div>
            <div className="w-full h-64 rounded-2xl overflow-hidden border border-gray-100">
              <iframe
                title="Anbu Fruit & Vegetable Shop Balakrishnapuram Location Map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3924.810123456789!2d77.9801234!3d10.3601234!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b00ab1234567890%3A0x1234567890abcdef!2sBalakrishnapuram%2C%20Dindigul%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1680000000000!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Inquiry Form */}
        <div className="lg:col-span-7">
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-gray-200 shadow-sm space-y-6">
            <div>
              <span className="text-xs font-bold text-[#4CAF50] uppercase tracking-wider">Send A Message</span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#2D5A27]">
                Produce Inquiry & Order Request Form
              </h2>
              <p className="text-gray-500 text-xs sm:text-sm mt-1">
                Fill in your details below and our shop representative will contact you within 30 minutes.
              </p>
            </div>

            {submitted ? (
              <div className="p-8 bg-[#F0FDF4] border border-[#4CAF50] rounded-2xl text-center space-y-3 animate-fadeIn">
                <CheckCircle2 className="w-12 h-12 text-[#4CAF50] mx-auto" />
                <h3 className="text-xl font-bold text-[#2D5A27]">Thank You, {formData.name}!</h3>
                <p className="text-sm text-gray-700">
                  Your inquiry regarding "<strong>{formData.subject}</strong>" has been received. Our team will contact you at <strong>{formData.mobile}</strong> shortly!
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {errorMessage && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-600 font-bold flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-800">Your Full Name *</label>
                    <input
                      type="text"
                      name="name"
                      placeholder="e.g. R. Kanthasamy"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      id="contact-input-name"
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#4CAF50]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-800">Mobile Number *</label>
                    <input
                      type="tel"
                      name="mobile"
                      placeholder="e.g. 9876543210"
                      value={formData.mobile}
                      onChange={handleChange}
                      required
                      id="contact-input-mobile"
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#4CAF50]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-800">Email Address (Optional)</label>
                    <input
                      type="email"
                      name="email"
                      placeholder="your.email@gmail.com"
                      value={formData.email}
                      onChange={handleChange}
                      id="contact-input-email"
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#4CAF50]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-800">Inquiry Subject</label>
                    <select
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      id="contact-select-subject"
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#4CAF50] bg-white"
                    >
                      <option value="General Inquiry">General Product Inquiry</option>
                      <option value="Daily Home Delivery">Home Delivery Request</option>
                      <option value="Organic Vegetables">Organic Keerai & Produce</option>
                      <option value="Wholesale Bulk Order">Marriage / Festival Bulk Order</option>
                      <option value="MCA Project Inquiry">MCA Academic Project Feedback</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-800">Your Message / Produce List *</label>
                  <textarea
                    name="message"
                    rows={4}
                    placeholder="Describe what produce items you are looking for or mention your delivery area in Dindigul..."
                    value={formData.message}
                    onChange={handleChange}
                    required
                    id="contact-textarea-message"
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#4CAF50]"
                  />
                </div>

                <button
                  type="submit"
                  id="contact-submit-btn"
                  className="w-full py-3.5 bg-[#2D5A27] hover:bg-[#23471f] text-white font-extrabold text-sm rounded-xl shadow-md transition-transform active:scale-95 flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" /> Send Inquiry Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
