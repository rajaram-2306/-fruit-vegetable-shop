import React, { useState } from 'react';
import { FileText, Code, CheckCircle, Search, Copy, Download, Layers, ShieldCheck, Globe, Database, Terminal } from 'lucide-react';

export const ProjectDocs: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'report' | 'seo' | 'files'>('report');
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  const handleCopy = (content: string, fileName: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFile(fileName);
    setTimeout(() => setCopiedFile(null), 3000);
  };

  const robotsTxtContent = `User-agent: *
Allow: /
Disallow: /admin/
Disallow: /private/

# Sitemap location
Sitemap: https://anbufreshdindigul.com/sitemap.xml
`;

  const sitemapXmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://anbufreshdindigul.com/</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://anbufreshdindigul.com/about</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://anbufreshdindigul.com/products</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>https://anbufreshdindigul.com/gallery</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://anbufreshdindigul.com/blog</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://anbufreshdindigul.com/contact</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
</urlset>`;

  const readmeMdContent = `# Anbu Fruit & Vegetable Shop - Web Portal
Official Web Application & E-Catalog for Anbu Fruit & Vegetable Shop, Balakrishnapuram, Dindigul. Developed as an MCA Final Year Mini/Major Project.

## Tech Stack
- **Frontend Framework:** React 18 with TypeScript
- **Styling:** Tailwind CSS (v4) with "Natural Tones" palette (#2D5A27, #4CAF50, #F27D26)
- **Icons:** Lucide React
- **Build Tool:** Vite

## Key Features
1. Responsive Single Page Application (SPA) architecture.
2. Complete catalog of fruits, vegetables, organic keerais, and daily grocery items.
3. Interactive Cart Basket with automatic WhatsApp order dispatch formatting.
4. Direct telephone and WhatsApp integration (+91 94876 02371).
5. Comprehensive MCA Academic Documentation & SEO Schema.org LocalBusiness compliance.

## Installation & Running Locally
\`\`\`bash
npm install
npm run dev
\`\`\`
`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Page Header */}
      <div className="bg-[#2D5A27] text-white rounded-3xl p-8 sm:p-12 shadow-xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-3 max-w-2xl">
          <span className="px-3 py-1 bg-[#F27D26] text-white font-extrabold text-xs uppercase tracking-wider rounded-full">
            MCA Academic Submission
          </span>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
            MCA Project Documentation & SEO Hub
          </h1>
          <p className="text-gray-100 text-sm sm:text-base leading-relaxed">
            Full technical documentation, architectural specifications, search engine optimization strategy, and project files for Anbu Fruit & Vegetable Shop.
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-white/10 backdrop-blur-md p-1.5 rounded-2xl border border-white/20 shrink-0">
          <button
            onClick={() => setActiveTab('report')}
            id="doc-tab-report"
            className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all ${
              activeTab === 'report' ? 'bg-white text-[#2D5A27] shadow-md' : 'text-white hover:bg-white/10'
            }`}
          >
            Project Report
          </button>
          <button
            onClick={() => setActiveTab('seo')}
            id="doc-tab-seo"
            className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all ${
              activeTab === 'seo' ? 'bg-white text-[#2D5A27] shadow-md' : 'text-white hover:bg-white/10'
            }`}
          >
            SEO Report
          </button>
          <button
            onClick={() => setActiveTab('files')}
            id="doc-tab-files"
            className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all ${
              activeTab === 'files' ? 'bg-white text-[#2D5A27] shadow-md' : 'text-white hover:bg-white/10'
            }`}
          >
            Config Files
          </button>
        </div>
      </div>

      {activeTab === 'report' && (
        <div className="bg-white rounded-3xl border border-gray-200 p-6 sm:p-12 shadow-sm space-y-10">
          {/* Metadata Title block */}
          <div className="p-6 bg-[#F0FDF4] border border-[#4CAF50]/30 rounded-2xl space-y-2 text-sm text-[#2D5A27]">
            <div className="font-extrabold text-lg text-[#2D5A27]">
              Master of Computer Applications (MCA) Project Specifications
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-semibold text-gray-700 pt-2 border-t border-[#4CAF50]/20">
              <div><strong>Project Title:</strong> Anbu Fruit & Vegetable Shop E-Commerce & Retail Portal</div>
              <div><strong>Location:</strong> Balakrishnapuram, Dindigul, Tamil Nadu</div>
              <div><strong>Architecture:</strong> Client-Side React SPA with Server-Side Gemini Capabilities</div>
              <div><strong>Status:</strong> Completed & Fully Functional</div>
            </div>
          </div>

          {/* CHAPTER 1 */}
          <section className="space-y-3">
            <h2 className="text-xl font-black text-[#2D5A27] border-l-4 border-[#F27D26] pl-3">
              Chapter 1: Introduction & Executive Abstract
            </h2>
            <p className="text-gray-700 text-sm leading-relaxed">
              The web application for <strong>Anbu Fruit & Vegetable Shop</strong> serves as an integrated digital e-catalog and direct customer engagement platform. Located in Balakrishnapuram, Dindigul, the store bridges local rural farmers and urban households. The primary objective of this MCA project is to transition traditional telephone produce inquiry into an interactive, structured, mobile-first web interface that allows customers to explore daily arrivals, understand produce nutrition benefits, calculate cart totals, and dispatch orders directly via WhatsApp.
            </p>
          </section>

          {/* CHAPTER 2 */}
          <section className="space-y-3">
            <h2 className="text-xl font-black text-[#2D5A27] border-l-4 border-[#F27D26] pl-3">
              Chapter 2: System Analysis & Feasibility
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div className="p-5 bg-red-50/50 rounded-2xl border border-red-100 space-y-2">
                <h3 className="font-bold text-red-900">2.1 Existing System Limitations</h3>
                <ul className="list-disc pl-4 text-xs text-gray-700 space-y-1">
                  <li>Reliance on manual paper scribbles and verbal phone calls.</li>
                  <li>No visual catalog for customers to inspect seasonal fruit freshness.</li>
                  <li>Inconsistent delivery order lists resulting in fulfillment errors.</li>
                </ul>
              </div>

              <div className="p-5 bg-green-50/50 rounded-2xl border border-green-100 space-y-2">
                <h3 className="font-bold text-green-900">2.2 Proposed Digital Solution</h3>
                <ul className="list-disc pl-4 text-xs text-gray-700 space-y-1">
                  <li>Instant, real-time product search, category filter, and sorting.</li>
                  <li>Automated cart total and free home delivery calculation above ₹300.</li>
                  <li>Pre-formatted WhatsApp order dispatch containing exact item counts and prices.</li>
                </ul>
              </div>
            </div>
          </section>

          {/* CHAPTER 3 */}
          <section className="space-y-3">
            <h2 className="text-xl font-black text-[#2D5A27] border-l-4 border-[#F27D26] pl-3">
              Chapter 3: Data Structure & TypeScript Types
            </h2>
            <div className="bg-gray-900 text-gray-100 p-5 rounded-2xl text-xs font-mono overflow-x-auto">
              <pre>{`export interface Product {
  id: string;
  name: string;
  category: 'fruit' | 'vegetable' | 'organic' | 'grocery';
  price: number;
  unit: string;
  image: string;
  description: string;
  isPopular?: boolean;
  isOrganic?: boolean;
  stockStatus: 'In Stock' | 'Limited Stock' | 'Pre-Order';
  origin?: string;
  benefits?: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
}`}</pre>
            </div>
          </section>

          {/* CHAPTER 4 */}
          <section className="space-y-3">
            <h2 className="text-xl font-black text-[#2D5A27] border-l-4 border-[#F27D26] pl-3">
              Chapter 4: Modules & Functional Architecture
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="font-bold text-gray-900 mb-1">Module 1: E-Catalog Engine</div>
                <div className="text-gray-600">Filters fruits, vegetables, organic greens, and daily grocery items with sub-second responsive performance.</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="font-bold text-gray-900 mb-1">Module 2: Cart & Dispatcher</div>
                <div className="text-gray-600">Manages item state, calculates delivery thresholds, and formats WhatsApp messages.</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="font-bold text-gray-900 mb-1">Module 3: Health & Nutrition Blog</div>
                <div className="text-gray-600">Educates consumers on fruit vitamins, organic farming, and Dindigul agricultural news.</div>
              </div>
            </div>
          </section>

          {/* CHAPTER 5 */}
          <section className="space-y-3">
            <h2 className="text-xl font-black text-[#2D5A27] border-l-4 border-[#F27D26] pl-3">
              Chapter 5: Testing & WCAG Accessibility
            </h2>
            <p className="text-gray-700 text-sm leading-relaxed">
              The application underwent rigorous multi-device testing on Android mobile viewports, iOS Safari, and Desktop Chrome. Contrast ratios meet WCAG AA standards with custom focus states, clear touch targets (&ge; 44px), and lightweight image optimization via Unsplash CDN.
            </p>
          </section>
        </div>
      )}

      {activeTab === 'seo' && (
        <div className="bg-white rounded-3xl border border-gray-200 p-6 sm:p-12 shadow-sm space-y-8">
          <div className="space-y-2">
            <h2 className="text-2xl font-extrabold text-[#2D5A27]">Local SEO & Google Search Strategy</h2>
            <p className="text-gray-600 text-sm">
              Targeting local search keywords for Balakrishnapuram and Dindigul produce queries.
            </p>
          </div>

          {/* Keywords Table */}
          <div className="overflow-x-auto border border-gray-200 rounded-2xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#2D5A27] text-white">
                <tr>
                  <th className="p-3">Target Search Keyword</th>
                  <th className="p-3">Intent</th>
                  <th className="p-3">Target Page</th>
                  <th className="p-3">Priority</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="p-3 font-bold">Anbu fruit and vegetable shop Dindigul</td>
                  <td className="p-3">Brand Local Search</td>
                  <td className="p-3">Home Page</td>
                  <td className="p-3 text-[#4CAF50] font-bold">High (1.0)</td>
                </tr>
                <tr>
                  <td className="p-3 font-bold">Fresh vegetable shop in Balakrishnapuram</td>
                  <td className="p-3">Geo-targeted Local</td>
                  <td className="p-3">Products Page</td>
                  <td className="p-3 text-[#4CAF50] font-bold">High (0.9)</td>
                </tr>
                <tr>
                  <td className="p-3 font-bold">Buy organic keerai in Dindigul</td>
                  <td className="p-3">Niche Organic Search</td>
                  <td className="p-3">Products & Services</td>
                  <td className="p-3 text-[#4CAF50] font-bold">High (0.9)</td>
                </tr>
                <tr>
                  <td className="p-3 font-bold">Dindigul marriage function vegetable delivery</td>
                  <td className="p-3">Wholesale / Catering</td>
                  <td className="p-3">Services</td>
                  <td className="p-3 text-[#F27D26] font-bold">Medium (0.8)</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Schema.org LocalBusiness JSON-LD preview */}
          <div className="space-y-2">
            <h3 className="font-extrabold text-gray-900 text-base">Schema.org Structured Data (JSON-LD)</h3>
            <div className="bg-gray-900 text-gray-100 p-5 rounded-2xl text-xs font-mono overflow-x-auto">
              <pre>{`<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "GroceryStore",
  "name": "Anbu Fruit & Vegetable Shop",
  "image": "https://anbufreshdindigul.com/hero_fruit_store.jpg",
  "telephone": "+919487602371",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Balakrishnapuram",
    "addressLocality": "Dindigul",
    "addressRegion": "Tamil Nadu",
    "postalCode": "624005",
    "addressCountry": "IN"
  },
  "openingHours": "Mo-Su 07:00-21:00",
  "priceRange": "₹"
}
</script>`}</pre>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'files' && (
        <div className="space-y-8">
          {/* File 1: robots.txt */}
          <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-sm text-[#2D5A27]">
                <FileText className="w-4 h-4 text-[#F27D26]" /> public/robots.txt
              </div>
              <button
                onClick={() => handleCopy(robotsTxtContent, 'robots.txt')}
                className="px-3 py-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-xs font-bold flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                {copiedFile === 'robots.txt' ? 'Copied!' : 'Copy Code'}
              </button>
            </div>
            <pre className="bg-gray-900 text-green-400 p-4 rounded-xl text-xs font-mono overflow-x-auto">
              {robotsTxtContent}
            </pre>
          </div>

          {/* File 2: sitemap.xml */}
          <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-sm text-[#2D5A27]">
                <Globe className="w-4 h-4 text-[#F27D26]" /> public/sitemap.xml
              </div>
              <button
                onClick={() => handleCopy(sitemapXmlContent, 'sitemap.xml')}
                className="px-3 py-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-xs font-bold flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                {copiedFile === 'sitemap.xml' ? 'Copied!' : 'Copy Code'}
              </button>
            </div>
            <pre className="bg-gray-900 text-amber-300 p-4 rounded-xl text-xs font-mono overflow-x-auto">
              {sitemapXmlContent}
            </pre>
          </div>

          {/* File 3: README.md */}
          <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-sm text-[#2D5A27]">
                <Terminal className="w-4 h-4 text-[#F27D26]" /> README.md
              </div>
              <button
                onClick={() => handleCopy(readmeMdContent, 'README.md')}
                className="px-3 py-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-xs font-bold flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                {copiedFile === 'README.md' ? 'Copied!' : 'Copy Code'}
              </button>
            </div>
            <pre className="bg-gray-900 text-gray-100 p-4 rounded-xl text-xs font-mono overflow-x-auto">
              {readmeMdContent}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
