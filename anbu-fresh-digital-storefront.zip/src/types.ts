export type PageType = 'home' | 'about' | 'products' | 'gallery' | 'contact' | 'blog' | 'docs';

export type ProductCategory = 'all' | 'fruit' | 'vegetable' | 'organic' | 'grocery' | 'service';

export interface Product {
  id: string;
  name: string;
  category: 'fruit' | 'vegetable' | 'organic' | 'grocery';
  price: number;
  unit: string;
  image: string;
  description: string;
  isPopular?: boolean;
  isOrganic?: boolean;
  isFreshArrival?: boolean;
  stockStatus: 'In Stock' | 'Limited Stock' | 'Pre-Order';
  origin?: string;
  benefits?: string[];
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  image: string;
  badge?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'fruits' | 'vegetables' | 'store' | 'grocery' | 'arrivals';
  image: string;
  caption: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  location: string;
  comment: string;
  rating: number;
  avatar: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string; // Full text (>400 words)
  featuredImage: string;
  author: string;
  authorRole: string;
  date: string;
  readTime: string;
  tags: string[];
}

export interface ContactFormData {
  name: string;
  mobile: string;
  email: string;
  subject: string;
  message: string;
}
